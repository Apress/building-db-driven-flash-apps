Public Class reportsMenu

    Inherits System.Web.UI.Page
    Protected WithEvents Baskets As System.Web.UI.WebControls.Label
    Protected WithEvents ordersMonth As System.Web.UI.WebControls.Button
    Protected WithEvents bsktsMonth As System.Web.UI.WebControls.Button
    Protected WithEvents bsktUtilization As System.Web.UI.WebControls.Button
    Protected WithEvents dgDataDisplay As System.Web.UI.WebControls.DataGrid
    Protected WithEvents dgDataDisplay2 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents bsktItemsMonth As System.Web.UI.WebControls.Button
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub bsktsMonth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bsktsMonth.Click

        Dim objCMD As New OleDb.OleDbCommand()
        Dim objConn As New OleDb.OleDbConnection()
        Dim strSQL As String
        Dim objDR As OleDb.OleDbDataReader

        '  Open the connection
        objConn.ConnectionString = Session("strConn")
        objConn.Open()

        '  Set the connection for the command object
        objCMD.Connection = objConn

        '  Query against the Access query/view for the baskets by month
        strSQL = "select * from BasketsByMonth"

        '  Set the query
        objCMD.CommandText = strSQL

        '  Set the data reader
        objDR = objCMD.ExecuteReader(CommandBehavior.CloseConnection)

        ' Show the data
        dgDataDisplay.DataSource = objDR
        dgDataDisplay.DataBind()

        dgDataDisplay2.Visible = False

    End Sub

    Private Sub bsktUtilization_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bsktUtilization.Click

        Dim objCMD As New OleDb.OleDbCommand()
        Dim objConn As New OleDb.OleDbConnection()
        Dim strSQL As String
        Dim objDR As OleDb.OleDbDataReader

        '  Open the connection
        objConn.ConnectionString = Session("strConn")
        objConn.Open()

        '  Set the commad connection
        objCMD.Connection = objConn

        '  Build the query to return the number of abandoned baskets
        strSQL = "select * from AbandonedBaskets"

        '  Set the command query
        objCMD.CommandText = strSQL

        '  Set the data reader
        objDR = objCMD.ExecuteReader(CommandBehavior.CloseConnection)

        ' *** KILL AND REPLACE WITH APPROPRIATE CALL TO FLASH
        dgDataDisplay.DataSource = objDR
        dgDataDisplay.DataBind()

        '  Close the reader for reuse
        objDR.Close()

        '  Re-open the connection
        objConn.Open()

        '  Get the number of ordered baskets
        strSQL = "select * from OrderedBaskets"

        '  Set the command query
        objCMD.CommandText = strSQL

        '  Set the data reader
        objDR = objCMD.ExecuteReader(CommandBehavior.CloseConnection)

        ' Show the data
        dgDataDisplay2.Visible = True
        dgDataDisplay2.DataSource = objDR
        dgDataDisplay2.DataBind()


    End Sub

    Private Sub ordersMonth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ordersMonth.Click

        Dim objCMD As New OleDb.OleDbCommand()
        Dim objConn As New OleDb.OleDbConnection()
        Dim strSQL As String
        Dim objDR As OleDb.OleDbDataReader

        '  Open the database connection
        objConn.ConnectionString = Session("strConn")
        objConn.Open()

        '  Set the connection for the command
        objCMD.Connection = objConn

        '  Build the query to return the order totals from the Access query/view
        strSQL = "select * from OrderTotalsByMonth"

        '  Set the query for the command object
        objCMD.CommandText = strSQL

        '  Set the data reader
        objDR = objCMD.ExecuteReader(CommandBehavior.CloseConnection)

        ' Show the data
        dgDataDisplay.DataSource = objDR
        dgDataDisplay.DataBind()

        dgDataDisplay2.Visible = False

    End Sub

    Private Sub bsktItemsMonth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bsktItemsMonth.Click

        Dim objCMD As New OleDb.OleDbCommand()
        Dim objConn As New OleDb.OleDbConnection()
        Dim strSQL As String
        Dim objDR As OleDb.OleDbDataReader

        '  Open the connection
        objConn.ConnectionString = Session("strConn")
        objConn.Open()

        '  Set the connection for the commad
        objCMD.Connection = objConn

        '  Build the query to retrieve the number of baskets for each month
        strSQL = "select * from BasketItemsByMonth"

        '  Set the command query
        objCMD.CommandText = strSQL

        '  Set the data reader
        objDR = objCMD.ExecuteReader(CommandBehavior.CloseConnection)

        ' Show the data
        dgDataDisplay.DataSource = objDR
        dgDataDisplay.DataBind()

        dgDataDisplay2.Visible = False

    End Sub
End Class
